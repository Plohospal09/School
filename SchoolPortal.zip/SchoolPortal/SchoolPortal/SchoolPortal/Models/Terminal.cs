﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;

namespace SchoolPortal.Models
{
    internal class Terminal
    {
        public static string Name;
        static public Peoples Chater;
        static public Peoples User;
        static public Frame frame;
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SchoolPortal.Models
{
    internal class CurrentLesson
    {
        public string CurrentLessonString { get; set; }
        public int ClassId { get; set; }
        public int LessonId { get; set; }


    }
}
